services:
  - type: web
    name: VertaVerse
    env: python
    buildCommand: ""
    startCommand: python app.py
    plan: free