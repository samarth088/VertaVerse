body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: #eef2f7;
    margin: 0;
    padding: 20px;
    color: #333;
}

header {
    text-align: center;
    margin-bottom: 30px;
}

h1 {
    font-size: 3em;
    color: #0077cc;
    margin-bottom: 5px;
}

h2 {
    color: #004a99;
    border-bottom: 2px solid #0077cc;
    padding-bottom: 8px;
}

.news-section {
    margin-bottom: 40px;
}

ul {
    list-style-type: none;
    padding-left: 0;
}

li {
    background: #fff;
    margin: 8px 0;
    padding: 12px 15px;
    border-radius: 8px;
    box-shadow: 0 1px 4px rgba(0,0,0,0.1);
    transition: background-color 0.3s;
}

li:hover {
    background-color: #d9ebff;
}

footer {
    text-align: center;
    margin-top: 50px;
    font-size: 0.9em;
    color: #666;
}